// src/features/sales/components/ProductSelectionModal.tsx
import { useState, useEffect, useMemo, useRef } from "react";
import {
  useGetProductsQuery,
  useGetCategoriesQuery,
} from "../../../services/inventoryApi";
import { useAppDispatch } from "../../../app/hooks";
import { addOrderProduct } from "../salesSlice";
import ProductCard from "./Productcard";
import ProductPopup from "./Productpopup";
import { XMarkIcon } from "@heroicons/react/24/outline";
import search_icon from "../../../assets/icons/search_icon.svg";
// import barcode_icon from "../../../assets/icons/barcode_icon.svg";

const API_BASE_URL =
  import.meta.env.VITE_API_URL?.replace("/api", "") ||
  "https://erp-backend.ttexpresskw.com";

interface ProductSelectionModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface MappedProduct {
  id: string;
  product_id: number;
  name: string;
  sku: string;
  price: number;
  stock: number;
  image: string;
  image_url: string;
  category: string;
  outOfStock: boolean;
}

export default function ProductSelectionModal({
  isOpen,
  onClose,
}: ProductSelectionModalProps) {
  const dispatch = useAppDispatch();
  const [searchQuery, setSearchQuery] = useState("");
  const [barcodeInput, setBarcodeInput] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All Items");
  const [isProductPopupOpen, setIsProductPopupOpen] = useState(false);
  const [currentProduct, setCurrentProduct] = useState<MappedProduct | null>(
    null,
  );
  // const [isBarcodeScanning, setIsBarcodeScanning] = useState(false);
  // const [barcodeError, setBarcodeError] = useState("");
  const barcodeInputRef = useRef<HTMLInputElement>(null);

  // ─── Real API ─────────────────────────────────────────────────
  const { data: productsResponse, isLoading, error } = useGetProductsQuery();
  const { data: categoriesResponse } = useGetCategoriesQuery();

  const categories = useMemo(() => {
    const apiCategories = categoriesResponse?.data?.data || [];
    return [
      "All Items",
      ...apiCategories
        .filter((cat: any) => cat.is_active)
        .map((cat: any) => cat.category_name),
    ];
  }, [categoriesResponse]);

  const products: MappedProduct[] = useMemo(() => {
    const apiProducts = productsResponse?.data?.data || [];

    return apiProducts.map((product: any) => {
      const totalStock =
        product.inventory?.reduce(
          (sum: number, inv: any) =>
            sum + (inv.available_quantity ?? inv.quantity ?? 0),
          0,
        ) || 0;

      const imagePath = product.primary_image?.image_path
        ? `${API_BASE_URL}/storage/${product.primary_image.image_path}`
        : "https://images.unsplash.com/photo-1541275055241-329bbdf9a191?w=500&auto=format&fit=crop&q=60";

      return {
        id: product.id.toString(),
        product_id: product.id,
        name: product.product_name || "",
        sku: product.sku || "",
        price:
          typeof product.selling_price === "string"
            ? parseFloat(product.selling_price)
            : product.selling_price || 0,
        stock: totalStock,
        outOfStock: totalStock <= 0,
        image: imagePath,
        image_url: product.primary_image?.image_path || "",
        category: product.category?.category_name || "All Items",
      };
    });
  }, [productsResponse]);

  const [filteredProducts, setFilteredProducts] = useState<MappedProduct[]>([]);

  useEffect(() => {
    let filtered = products;
    if (selectedCategory !== "All Items") {
      filtered = filtered.filter((p) =>
        p.category.toLowerCase().includes(selectedCategory.toLowerCase()),
      );
    }
    if (searchQuery.trim() !== "") {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(
        (p) =>
          p.name.toLowerCase().includes(query) ||
          p.sku.toLowerCase().includes(query),
      );
    }
    setFilteredProducts(filtered);
  }, [searchQuery, selectedCategory, products]);

  // Handle barcode scan
  // const handleBarcodeScan = async () => {
  //   if (!barcodeInput.trim()) {
  //     setBarcodeError("Please enter or scan a barcode");
  //     return;
  //   }

  //   setIsBarcodeScanning(true);
  //   setBarcodeError("");

  //   try {
  //     // First try to find product by barcode in the products list
  //     const foundProduct = products.find(
  //       (p) => p.sku.toLowerCase() === barcodeInput.trim().toLowerCase(),
  //     );

  //     if (foundProduct) {
  //       // Add product directly to order
  //       const uniqueId = `${foundProduct.product_id}-default-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

  //       dispatch(
  //         addOrderProduct({
  //           id: uniqueId,
  //           product_id: foundProduct.product_id,
  //           name: foundProduct.name,
  //           sku: foundProduct.sku,
  //           price: foundProduct.price,
  //           size: "Default",
  //           variant_id: null,
  //           quantity: 1,
  //           image: foundProduct.image,
  //           image_url: foundProduct.image_url,
  //         }),
  //       );

  //       setBarcodeInput("");
  //       // Optional: show success toast
  //       console.log("Product added via barcode:", foundProduct.name);
  //     } else {
  //       setBarcodeError(`Product with barcode "${barcodeInput}" not found`);
  //     }
  //   } catch (err) {
  //     setBarcodeError("Failed to find product");
  //   } finally {
  //     setIsBarcodeScanning(false);
  //     // Refocus barcode input for next scan
  //     setTimeout(() => {
  //       barcodeInputRef.current?.focus();
  //     }, 100);
  //   }
  // };

  const handleProductClick = (product: MappedProduct) => {
    setCurrentProduct(product);
    setIsProductPopupOpen(true);
  };

  const handleAddToSelection = (productWithDetails: any) => {
    const uniqueId = `${currentProduct?.product_id}-${productWithDetails.variant_id || "default"}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;

    const fullImageUrl = currentProduct?.image || "";

    dispatch(
      addOrderProduct({
        id: uniqueId,
        product_id: currentProduct?.product_id || 0,
        name: productWithDetails.name || currentProduct?.name || "",
        sku: productWithDetails.sku || currentProduct?.sku || "",
        price: productWithDetails.price || currentProduct?.price || 0,
        size: productWithDetails.size || "Default",
        variant_id: productWithDetails.variant_id ?? null,
        quantity: productWithDetails.quantity || 1,
        image: currentProduct?.image || "",
        image_url: fullImageUrl,
         discount_percentage: 0,
      }),
    );

    setIsProductPopupOpen(false);
    setCurrentProduct(null);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-end sm:items-center justify-center z-50 p-0 sm:p-4">
      {/* Modal Container - Slide up on mobile */}
      <div className="bg-white rounded-t-2xl sm:rounded-2xl w-full max-w-7xl max-h-[90vh] sm:max-h-[85vh] overflow-y-auto">
        {/* Header - Sticky */}
        <div className="sticky top-0 bg-white border-b border-gray-200 px-4 sm:px-6 py-3 sm:py-4 flex items-center justify-between z-10">
          <h2 className="text-base sm:text-lg md:text-xl font-bold text-gray-900">
            Select Products
          </h2>
          <button
            onClick={onClose}
            className="p-1.5 sm:p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <XMarkIcon className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        {/* Content */}
        <div className="p-3 sm:p-4 md:p-6">
          {/* Barcode Scanner Row */}
          {/* <div className="mb-4 p-3 bg-gray-50 rounded-xl border border-gray-200">
            <div className="flex items-center gap-2 mb-2">
              <img src={barcode_icon} alt="" className="w-5 h-5 text-gray-500" />
              <span className="text-sm font-medium text-gray-700">Quick Add by Barcode</span>
            </div>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <input
                  ref={barcodeInputRef}
                  type="text"
                  value={barcodeInput}
                  onChange={(e) => setBarcodeInput(e.target.value)}
                  onKeyDown={handleBarcodeKeyDown}
                  placeholder="Scan or enter barcode..."
                  className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                  disabled={isBarcodeScanning}
                  autoFocus
                />
              </div>
              <button
                onClick={handleBarcodeScan}
                disabled={isBarcodeScanning || !barcodeInput.trim()}
                className="px-5 py-2.5 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 transition-colors whitespace-nowrap"
              >
                {isBarcodeScanning ? (
                  <div className="flex items-center gap-2">
                    <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent" />
                    <span>Adding...</span>
                  </div>
                ) : (
                  'Add to Order'
                )}
              </button>
            </div>
            {barcodeError && (
              <p className="text-red-500 text-sm mt-2">{barcodeError}</p>
            )}
          </div> */}

          {/* Search Bar */}
          <div className="relative mb-4 sm:mb-6">
            <div className="absolute left-3 sm:left-4 top-1/2 -translate-y-1/2 text-gray-400">
              <img src={search_icon} alt="" className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by product name, SKU, or barcode"
              className="w-full pl-9 sm:pl-12 pr-12 sm:pr-16 py-2.5 sm:py-3.5 bg-white border border-gray-300 rounded-lg sm:rounded-xl text-gray-900 placeholder-gray-400 text-sm sm:text-base focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200 shadow-sm"
            />
          </div>

          {/* Category Tabs - Horizontal Scroll on Mobile */}
          <div className="mb-4 sm:mb-6 overflow-x-auto">
            <div className="p-2 sm:p-3 md:p-4 bg-gray-50 rounded-lg">
              <div className="flex gap-1.5 sm:gap-2 md:gap-3 min-w-max">
                {categories.map((category: string) => (
                  <button
                    key={category}
                    onClick={() => setSelectedCategory(category)}
                    className={`px-2.5 sm:px-3 md:px-4 lg:px-5 py-1.5 sm:py-2 md:py-2.5 rounded-md font-medium text-[10px] sm:text-xs md:text-sm whitespace-nowrap transition-all duration-200 cursor-pointer ${
                      selectedCategory === category
                        ? "border border-[#1773CF] text-black shadow-md shadow-blue-200 bg-white"
                        : "bg-white text-gray-700 border border-gray-200 hover:border-blue-300 hover:text-blue-600"
                    }`}
                  >
                    {category}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Product Grid */}
          {isLoading ? (
            <div className="flex items-center justify-center py-12 sm:py-16 md:py-20">
              <div className="flex flex-col items-center gap-3">
                <div className="animate-spin rounded-full h-8 w-8 sm:h-10 sm:w-10 border-b-2 border-blue-600" />
                <p className="text-gray-500 text-xs sm:text-sm">
                  Loading products...
                </p>
              </div>
            </div>
          ) : error ? (
            <div className="flex items-center justify-center py-12 sm:py-16 md:py-20">
              <p className="text-red-500 font-medium text-sm sm:text-base">
                Failed to load products. Please try again.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 min-[400px]:grid-cols-2 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-2 sm:gap-3 md:gap-4 lg:gap-5 xl:gap-6 p-2 sm:p-3 md:p-4">
              {filteredProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onAddToCart={() => handleProductClick(product)}
                />
              ))}
            </div>
          )}

          {/* Empty State */}
          {!isLoading && !error && filteredProducts.length === 0 && (
            <div className="flex flex-col items-center justify-center py-12 sm:py-16 md:py-20 px-4">
              <div className="w-16 h-16 sm:w-20 sm:h-20 md:w-24 md:h-24 bg-gray-100 rounded-full flex items-center justify-center mb-3 sm:mb-4">
                <svg
                  className="w-8 h-8 sm:w-10 sm:h-10 md:w-12 md:h-12 text-gray-400"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4"
                  />
                </svg>
              </div>
              <h3 className="text-base sm:text-lg font-semibold text-gray-900 mb-1 sm:mb-2">
                No products found
              </h3>
              <p className="text-xs sm:text-sm text-gray-600 text-center max-w-sm">
                Try adjusting your search or filter.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Nested Product Popup */}
      {isProductPopupOpen && currentProduct && (
        <ProductPopup
          product={currentProduct}
          onClose={() => {
            setIsProductPopupOpen(false);
            setCurrentProduct(null);
          }}
          onAdd={handleAddToSelection}
        />
      )}
    </div>
  );
}
